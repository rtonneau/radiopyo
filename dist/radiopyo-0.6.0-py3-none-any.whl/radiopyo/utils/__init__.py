#!/usr/bin/env python3
"""

Author:
    Romain Tonneau (romain.tonneau@unamur.be) - 26/07/2023
"""
# ----------------------------- External imports ---------------------------- #
from __future__ import annotations

import typing as tp

# ----------------------------- Internal imports ---------------------------- #
from .useful_path import (
    LABARBE_CONFIG_FILE,
    PACKAGE_DATA_PATH,
    PURE_WATER_CONFIG_FILE,
)

# ------------------------- Type checking ONLY imports----------------------- #
if tp.TYPE_CHECKING:
    pass

# ------------------------- Expose importable stuffs ------------------------ #
__all__: tp.List = [
    "PACKAGE_DATA_PATH",
    "LABARBE_CONFIG_FILE",
    "PURE_WATER_CONFIG_FILE",
]

# ---------------------------------- Logging -------------------------------- #

# --------------------------------------------------------------------------- #
#                            DECORATOR DEFINITIONS                            #
# --------------------------------------------------------------------------- #

# --------------------------------------------------------------------------- #
#                             FUNCTION DEFINITIONS                            #
# --------------------------------------------------------------------------- #

# --------------------------------------------------------------------------- #
#                              CLASS DEFINITIONS                              #
# --------------------------------------------------------------------------- #
