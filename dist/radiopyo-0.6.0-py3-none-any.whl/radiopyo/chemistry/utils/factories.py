#!/usr/bin/env python3
"""

Author:
    Romain Tonneau (romain.tonneau@unamur.be) - 27/08/2024
"""
# ----------------------------- External imports ---------------------------- #
from __future__ import annotations

import typing as tp

import numpy as np

# ----------------------------- Internal imports ---------------------------- #

# ------------------------- Type checking ONLY imports----------------------- #
if tp.TYPE_CHECKING:
    pass

# ------------------------- Expose importable stuffs ------------------------ #
__all__: tp.List = [
    "polynomial_factory",
]

# ---------------------------------- Logging -------------------------------- #

# --------------------------------------------------------------------------- #
#                            DECORATOR DEFINITIONS                            #
# --------------------------------------------------------------------------- #


# --------------------------------------------------------------------------- #
#                             FUNCTION DEFINITIONS                            #
# --------------------------------------------------------------------------- #
def polynomial_factory(
    value: float | tp.List[float] | np.polynomial.Polynomial,
    log10: bool = False,
) -> np.polynomial.Polynomial:
    """
    A factory function to create a numpy polynomial from a given value.

    Rem:
        For K values, literature contains polynomials of the form:
        Log(k) = 13.339 - (2.220e3/T) + (7.333e5 /T2) - (1.065e8/T3)
        Therefore, the KReaction class always handles log10 values. The
        log10 argument ensure that in the case of a single, constant,
        value the afterward computation will be good.
        => 10^(log10(k)) = k

    Args:
        value (float | tp.List[float] | np.polynomial.Polynomial):
            The value to be converted into a numpy polynomial. It can be
            a float, a list of floats or a numpy polynomial.

        log10 (bool, optional):
            If True, the value will be converted to log10. Defaults to
            False.

    Returns:
        np.polynomial.Polynomial:
            A numpy polynomial created from the given value.

    Raises:
        ValueError:
            If the given value is not a valid input for creating a
            numpy polynomial.
    """
    if isinstance(value, np.polynomial.Polynomial):
        return value
    if isinstance(value, (list, tuple, np.ndarray)):
        if len(value) == 1:
            _coef = [np.log10(value[0]) if log10 else value[0]]
        elif len(value) > 1:
            _coef = list(value)
        else:
            raise ValueError("Cannot make a polynomial with no coeff!")
    else:
        if value >= 0:
            _coef = [np.log10(value) if log10 else value]
        else:
            _coef = [-np.inf]

    return np.polynomial.Polynomial(_coef)


# --------------------------------------------------------------------------- #
#                              CLASS DEFINITIONS                              #
# --------------------------------------------------------------------------- #
